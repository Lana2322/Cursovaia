﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PsHospital1
{
    class Pacient
    {
        private string name = "";
        private int age = 0;
        private string data = "";
        private string genre = "";
        private bool danger = false;
        private int status = 0;
        private string diagnos = "";

        public Pacient()
        {
        }

        public Pacient(string inputName)
        {
            this.Name = inputName;
        }
        public Pacient(string inputName, int inputAge, string inputData, string inputGenre)
        {
            this.Name = inputName;
            this.Age = inputAge;
            this.Data = inputData;
            this.Genre = inputGenre;
        }

        public string Name { get ; set ; }
        public int Age { get; set; }
        public string Data { get ; set ; }
        public string Genre { get ; set ; }
        public bool Danger { get; set; }
        public int Status { get; set; }
        public string Diagnos { get; set; }
    }
}
